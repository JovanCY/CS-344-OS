gcc -o myCounter myCounter.c -lpthread
